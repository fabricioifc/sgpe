--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.perfil_roles DROP CONSTRAINT fk_rails_9a7cf06c02;
ALTER TABLE ONLY public.users_perfils DROP CONSTRAINT fk_rails_7e41f3188f;
ALTER TABLE ONLY public.users_perfils DROP CONSTRAINT fk_rails_63cdee4ad6;
ALTER TABLE ONLY public.cursos DROP CONSTRAINT fk_rails_3db4199c61;
ALTER TABLE ONLY public.perfil_roles DROP CONSTRAINT fk_rails_120cfd26bb;
ALTER TABLE ONLY public.disciplines DROP CONSTRAINT fk_rails_042a4cd755;
DROP INDEX public.index_users_perfils_on_user_id;
DROP INDEX public.index_users_perfils_on_perfil_id_and_user_id;
DROP INDEX public.index_users_perfils_on_perfil_id;
DROP INDEX public.index_users_on_username;
DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
DROP INDEX public.index_roles_on_name_and_resource_type_and_resource_id;
DROP INDEX public.index_perfils_on_name;
DROP INDEX public.index_perfil_roles_on_role_id;
DROP INDEX public.index_perfil_roles_on_perfil_id_and_role_id;
DROP INDEX public.index_perfil_roles_on_perfil_id;
DROP INDEX public.index_disciplines_on_user_id;
DROP INDEX public.index_cursos_on_user_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users_perfils DROP CONSTRAINT users_perfils_pkey;
ALTER TABLE ONLY public.tests DROP CONSTRAINT tests_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.perfils DROP CONSTRAINT perfils_pkey;
ALTER TABLE ONLY public.perfil_roles DROP CONSTRAINT perfil_roles_pkey;
ALTER TABLE ONLY public.disciplines DROP CONSTRAINT disciplines_pkey;
ALTER TABLE ONLY public.cursos DROP CONSTRAINT cursos_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE public.users_perfils ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.perfils ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.perfil_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.disciplines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cursos ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_perfils_id_seq;
DROP TABLE public.users_perfils;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.tests_id_seq;
DROP TABLE public.tests;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.perfils_id_seq;
DROP TABLE public.perfils;
DROP SEQUENCE public.perfil_roles_id_seq;
DROP TABLE public.perfil_roles;
DROP SEQUENCE public.disciplines_id_seq;
DROP TABLE public.disciplines;
DROP SEQUENCE public.cursos_id_seq;
DROP TABLE public.cursos;
DROP TABLE public.ar_internal_metadata;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cursos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE cursos (
    id bigint NOT NULL,
    title character varying,
    sigla character varying,
    description character varying,
    idativo boolean DEFAULT true,
    user_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cursos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cursos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cursos_id_seq OWNED BY cursos.id;


--
-- Name: disciplines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE disciplines (
    id bigint NOT NULL,
    title character varying(45) NOT NULL,
    description text NOT NULL,
    active boolean DEFAULT true,
    user_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: disciplines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE disciplines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: disciplines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE disciplines_id_seq OWNED BY disciplines.id;


--
-- Name: perfil_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE perfil_roles (
    id bigint NOT NULL,
    perfil_id bigint,
    role_id bigint
);


--
-- Name: perfil_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE perfil_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: perfil_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE perfil_roles_id_seq OWNED BY perfil_roles.id;


--
-- Name: perfils; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE perfils (
    id bigint NOT NULL,
    name character varying,
    idativo boolean DEFAULT true,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: perfils_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE perfils_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: perfils_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE perfils_id_seq OWNED BY perfils.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE posts (
    id bigint NOT NULL,
    title character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_id_seq OWNED BY posts.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE roles (
    id bigint NOT NULL,
    name character varying,
    resource_type character varying,
    resource_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE tests (
    id bigint NOT NULL,
    title character varying,
    body character varying,
    active boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: tests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tests_id_seq OWNED BY tests.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying,
    confirmation_token character varying,
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    unconfirmed_email character varying,
    avatar character varying,
    admin boolean DEFAULT false,
    username character varying
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_perfils; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users_perfils (
    id bigint NOT NULL,
    user_id bigint,
    perfil_id bigint
);


--
-- Name: users_perfils_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_perfils_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_perfils_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_perfils_id_seq OWNED BY users_perfils.id;


--
-- Name: cursos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY cursos ALTER COLUMN id SET DEFAULT nextval('cursos_id_seq'::regclass);


--
-- Name: disciplines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY disciplines ALTER COLUMN id SET DEFAULT nextval('disciplines_id_seq'::regclass);


--
-- Name: perfil_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfil_roles ALTER COLUMN id SET DEFAULT nextval('perfil_roles_id_seq'::regclass);


--
-- Name: perfils id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfils ALTER COLUMN id SET DEFAULT nextval('perfils_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts ALTER COLUMN id SET DEFAULT nextval('posts_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: tests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tests ALTER COLUMN id SET DEFAULT nextval('tests_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: users_perfils id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_perfils ALTER COLUMN id SET DEFAULT nextval('users_perfils_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2282.dat';

--
-- Data for Name: cursos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY cursos (id, title, sigla, description, idativo, user_id, created_at, updated_at) FROM stdin;
\.
COPY cursos (id, title, sigla, description, idativo, user_id, created_at, updated_at) FROM '$$PATH$$/2283.dat';

--
-- Name: cursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cursos_id_seq', 2, true);


--
-- Data for Name: disciplines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY disciplines (id, title, description, active, user_id, created_at, updated_at) FROM stdin;
\.
COPY disciplines (id, title, description, active, user_id, created_at, updated_at) FROM '$$PATH$$/2285.dat';

--
-- Name: disciplines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('disciplines_id_seq', 1, false);


--
-- Data for Name: perfil_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY perfil_roles (id, perfil_id, role_id) FROM stdin;
\.
COPY perfil_roles (id, perfil_id, role_id) FROM '$$PATH$$/2287.dat';

--
-- Name: perfil_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('perfil_roles_id_seq', 1, false);


--
-- Data for Name: perfils; Type: TABLE DATA; Schema: public; Owner: -
--

COPY perfils (id, name, idativo, created_at, updated_at) FROM stdin;
\.
COPY perfils (id, name, idativo, created_at, updated_at) FROM '$$PATH$$/2289.dat';

--
-- Name: perfils_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('perfils_id_seq', 1, false);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts (id, title, created_at, updated_at) FROM stdin;
\.
COPY posts (id, title, created_at, updated_at) FROM '$$PATH$$/2291.dat';

--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_id_seq', 1, false);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY roles (id, name, resource_type, resource_id, created_at, updated_at) FROM stdin;
\.
COPY roles (id, name, resource_type, resource_id, created_at, updated_at) FROM '$$PATH$$/2293.dat';

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('roles_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2295.dat';

--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tests (id, title, body, active, created_at, updated_at) FROM stdin;
\.
COPY tests (id, title, body, active, created_at, updated_at) FROM '$$PATH$$/2296.dat';

--
-- Name: tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tests_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, name, confirmation_token, confirmed_at, confirmation_sent_at, unconfirmed_email, avatar, admin, username) FROM stdin;
\.
COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, name, confirmation_token, confirmed_at, confirmation_sent_at, unconfirmed_email, avatar, admin, username) FROM '$$PATH$$/2298.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Data for Name: users_perfils; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_perfils (id, user_id, perfil_id) FROM stdin;
\.
COPY users_perfils (id, user_id, perfil_id) FROM '$$PATH$$/2300.dat';

--
-- Name: users_perfils_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_perfils_id_seq', 1, false);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: cursos cursos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cursos
    ADD CONSTRAINT cursos_pkey PRIMARY KEY (id);


--
-- Name: disciplines disciplines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY disciplines
    ADD CONSTRAINT disciplines_pkey PRIMARY KEY (id);


--
-- Name: perfil_roles perfil_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfil_roles
    ADD CONSTRAINT perfil_roles_pkey PRIMARY KEY (id);


--
-- Name: perfils perfils_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfils
    ADD CONSTRAINT perfils_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (id);


--
-- Name: users_perfils users_perfils_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_perfils
    ADD CONSTRAINT users_perfils_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_cursos_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cursos_on_user_id ON cursos USING btree (user_id);


--
-- Name: index_disciplines_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_disciplines_on_user_id ON disciplines USING btree (user_id);


--
-- Name: index_perfil_roles_on_perfil_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_perfil_roles_on_perfil_id ON perfil_roles USING btree (perfil_id);


--
-- Name: index_perfil_roles_on_perfil_id_and_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_perfil_roles_on_perfil_id_and_role_id ON perfil_roles USING btree (perfil_id, role_id);


--
-- Name: index_perfil_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_perfil_roles_on_role_id ON perfil_roles USING btree (role_id);


--
-- Name: index_perfils_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_perfils_on_name ON perfils USING btree (name);


--
-- Name: index_roles_on_name_and_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_roles_on_name_and_resource_type_and_resource_id ON roles USING btree (name, resource_type, resource_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_username ON users USING btree (username);


--
-- Name: index_users_perfils_on_perfil_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_perfils_on_perfil_id ON users_perfils USING btree (perfil_id);


--
-- Name: index_users_perfils_on_perfil_id_and_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_perfils_on_perfil_id_and_user_id ON users_perfils USING btree (perfil_id, user_id);


--
-- Name: index_users_perfils_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_perfils_on_user_id ON users_perfils USING btree (user_id);


--
-- Name: disciplines fk_rails_042a4cd755; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY disciplines
    ADD CONSTRAINT fk_rails_042a4cd755 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: perfil_roles fk_rails_120cfd26bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfil_roles
    ADD CONSTRAINT fk_rails_120cfd26bb FOREIGN KEY (perfil_id) REFERENCES perfils(id);


--
-- Name: cursos fk_rails_3db4199c61; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cursos
    ADD CONSTRAINT fk_rails_3db4199c61 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: users_perfils fk_rails_63cdee4ad6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_perfils
    ADD CONSTRAINT fk_rails_63cdee4ad6 FOREIGN KEY (perfil_id) REFERENCES perfils(id);


--
-- Name: users_perfils fk_rails_7e41f3188f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_perfils
    ADD CONSTRAINT fk_rails_7e41f3188f FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: perfil_roles fk_rails_9a7cf06c02; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY perfil_roles
    ADD CONSTRAINT fk_rails_9a7cf06c02 FOREIGN KEY (role_id) REFERENCES roles(id);


--
-- PostgreSQL database dump complete
--

